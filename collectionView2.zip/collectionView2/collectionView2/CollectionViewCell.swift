//
//  CollectionViewCell.swift
//  collectionView2
//
//  Created by Luis Fernando Perez on 29/01/18.
//  Copyright © 2018 Ricardo Coronado. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageFood: UIImageView!
    
    @IBOutlet weak var nameFood: UILabel!
}
