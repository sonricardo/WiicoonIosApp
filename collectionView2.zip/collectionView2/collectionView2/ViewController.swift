//
//  ViewController.swift
//  collectionView2
//
//  Created by Luis Fernando Perez on 29/01/18.
//  Copyright © 2018 Ricardo Coronado. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
   
    
    
   
    // variables
    
    let comidasNames: [String] = ["paella","pizza","sushi","taco","tamal"]
    
    
    
    // function view controller life
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionViewComidas.delegate = self
        collectionViewComidas.dataSource = self
        
        if (traitCollection.forceTouchCapability == .available){
            registerForPreviewing(with: self, sourceView: collectionViewComidas)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //IBOutlets
    
    @IBOutlet weak var collectionViewComidas: UICollectionView!
    
    // SYST function
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return comidasNames.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionViewComidas.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        cell.imageFood.image = UIImage(named: comidasNames[indexPath.row])
        cell.nameFood.text = comidasNames[indexPath.row]
        cell.layer.cornerRadius = 18
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let screen = UIScreen.main.bounds
        
        return CGSize(width: screen.width * 0.94, height: 220 )
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
    }
    
    
}

