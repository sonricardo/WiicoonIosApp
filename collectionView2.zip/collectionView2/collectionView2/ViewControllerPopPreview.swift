//
//  ViewControllerPopPreview.swift
//  collectionView2
//
//  Created by Luis Fernando Perez on 08/02/18.
//  Copyright © 2018 Ricardo Coronado. All rights reserved.
//

import UIKit

class ViewControllerPopPreview: UIViewController {

    
    @IBOutlet weak var imagePop: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    
  
}
