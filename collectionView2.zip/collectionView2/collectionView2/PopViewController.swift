//
//  PopViewController.swift
//  collectionView2
//
//  Created by Luis Fernando Perez on 08/02/18.
//  Copyright © 2018 Ricardo Coronado. All rights reserved.
//

import Foundation
import UIKit

class PopViewController: UIViewController {
    
    override func viewDidLoad() {
       
        }
    
    @IBOutlet weak var imagePop: UIView!
}
