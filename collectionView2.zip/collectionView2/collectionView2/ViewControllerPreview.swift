//
//  ViewControllerPreview.swift
//  collectionView2
//
//  Created by Luis Fernando Perez on 08/02/18.
//  Copyright © 2018 Ricardo Coronado. All rights reserved.
//

import UIKit

extension ViewController: UIViewControllerPreviewingDelegate{
    
    
    func previewingContext(_ previewingContext: UIViewControllerPreviewing, viewControllerForLocation location: CGPoint) -> UIViewController? {
        
        guard let indexPath = collectionViewComidas.indexPathForItem(at: location),
            let cell = collectionViewComidas.cellForItem(at: indexPath)
        else {
            return nil
        }
        guard let previewVc = storyboard?.instantiateViewController(withIdentifier: "popID") as? ViewControllerPopPreview
            else {
                return nil
        }
        previewVc.imagePop.image = UIImage(named: comidasNames[indexPath.row])
        previewVc.preferredContentSize = CGSize(width: 0, height: 150)
        
        previewingContext.sourceRect = cell.frame
        
        return previewVc
    }
    
    func previewingContext(_ previewingContext: UIViewControllerPreviewing, commit viewControllerToCommit: UIViewController) {
        
        
       // show( viewControllerToCommit, sender: self)
    }
    
    
}
